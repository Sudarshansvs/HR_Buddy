import os

from dotenv import load_dotenv

load_dotenv()


class Settings:
    APP_NAME: str = os.getenv("APP_NAME", "HR Buddy")

    LLM_MODEL: str = os.getenv(
        "LLM_MODEL",
        "llama3.2:3b"
    )

    OLLAMA_HOST: str = os.getenv(
        "OLLAMA_HOST",
        "http://localhost:11434"
    )

    TOP_K: int = int(
        os.getenv("TOP_K", "5")
    )

    CHUNK_SIZE: int = int(
        os.getenv("CHUNK_SIZE", "500")
    )

    CHUNK_OVERLAP: int = int(
        os.getenv("CHUNK_OVERLAP", "100")
    )

    DOCUMENTS_PATH: str = os.getenv(
        "DOCUMENTS_PATH",
        "data/documents"
    )


settings = Settings()