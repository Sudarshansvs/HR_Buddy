import logging

from hr_buddy.app.rag.loader import DocumentLoader
from hr_buddy.app.rag.chunker import TextChunker
from hr_buddy.app.rag.retriever import Retriever
from hr_buddy.app.core.config import settings


logger = logging.getLogger(__name__)


class RetrievalService:

    def __init__(self):

        self.loader = DocumentLoader(
            settings.DOCUMENTS_PATH
        )

        self.chunker = TextChunker()

        self.retriever = Retriever()

        self.initialize()

    def initialize(self):

        documents = (
            self.loader.load_documents()
        )

        chunks = []

        for document in documents:

            document_chunks = (
                self.chunker.split(
                    document["content"]
                )
            )

            for chunk in document_chunks:

                chunks.append(
                    {
                        "document": document[
                            "document"
                        ],
                        "content": chunk
                    }
                )

        if chunks:

            self.retriever.build_index(
                chunks
            )

            logger.info(
                "Indexed %s chunks",
                len(chunks)
            )

    def search(self, question):

        return self.retriever.retrieve(
            question,
            settings.TOP_K
        )